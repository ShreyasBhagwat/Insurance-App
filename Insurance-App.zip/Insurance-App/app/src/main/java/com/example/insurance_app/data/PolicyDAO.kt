package com.example.insurance_app.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface PolicyDAO {
    @Insert
    fun insertAll(vararg policies:Policy)

    @Insert
    fun insert(policy: Policy)

    @Delete
    fun delete(policy:Policy)

    @Query("SELECT * FROM policy order by PolicyName")
    fun getAll():LiveData<List<Policy>>

    @Update
    fun update(policy:Policy)


}