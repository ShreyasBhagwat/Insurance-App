
package com.example.insurance_app.utilities

/**
 * Constants used throughout the app.
 */
const val DATABASE_NAME = "insurance_database-db"
const val USER_DATA_FILENAME = "users.json"
